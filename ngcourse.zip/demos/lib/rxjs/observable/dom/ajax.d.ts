import { AjaxCreationMethod } from './AjaxObservable';
export declare const ajax: AjaxCreationMethod;

import { GenerateObservable } from './GenerateObservable';
export declare const generate: typeof GenerateObservable.create;

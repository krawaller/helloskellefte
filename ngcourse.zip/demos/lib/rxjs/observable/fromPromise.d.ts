import { PromiseObservable } from './PromiseObservable';
export declare const fromPromise: typeof PromiseObservable.create;

import { BoundNodeCallbackObservable } from './BoundNodeCallbackObservable';
export declare const bindNodeCallback: typeof BoundNodeCallbackObservable.create;

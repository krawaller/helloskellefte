import { InjectionToken } from '@angular/core'

export const finalAnswerToken = new InjectionToken('answer')

export const finalAnswerVal = 42
Showing off a Pipe implementation.

In Angular1 these constructs were called filters.
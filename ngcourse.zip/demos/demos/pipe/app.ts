import {Component} from '@angular/core'

@Component({
  selector: 'app',
  template: `<p>Behold! {{ "David" | McFaceIt }} is on the rise!</p>`,
})
export class AppComponent {}

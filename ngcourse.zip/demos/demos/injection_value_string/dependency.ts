export const finalAnswerToken = 'MYSECRETANSWER'

export const finalAnswerVal = 42
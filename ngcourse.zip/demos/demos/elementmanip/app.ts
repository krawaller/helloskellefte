import {Component,ElementRef} from '@angular/core';

@Component({
  selector: 'app',
  template: `
    <p swedify>I am Swedish!</p>
    `
})
export class AppComponent {}

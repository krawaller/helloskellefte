Showing how we can use `ElementRef` as a `@Directive` dependency to manipulate the DOM node.

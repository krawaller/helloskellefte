export default class Dependency {
  foo: string = 'bar'
}
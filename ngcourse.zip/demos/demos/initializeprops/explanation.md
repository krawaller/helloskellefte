See how Typescript makes it easy to initialize a prop!
